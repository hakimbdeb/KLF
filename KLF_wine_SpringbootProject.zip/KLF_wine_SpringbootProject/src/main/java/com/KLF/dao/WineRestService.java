/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.KLF.dao;

import com.KLF.modele.Products;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Hakim
 */
@RestController
public class WineRestService {

    @Autowired
    private ProductsRepository productsRepository;

    @RequestMapping(value = "/products", method = RequestMethod.GET)
    //Have a search function getting a wine number as input returning  a JSON representation of 5 fields of the ‘Products’ table
    public List<Products> listProducts() {
        List<Products> listP = productsRepository.findAll();
        List<Products> listFive = new ArrayList<>();
        int i = 0;
        String name;
        double prix;
        for (Products tmp : listP) {
            if (i < 5) {
                name = tmp.getProdName();
                prix = tmp.getProdSellPrice();
                Products p = new Products(name, prix);
                listFive.add(p);

            }
        }
        return listFive;
    }

}
