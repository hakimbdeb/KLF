/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.KLF.dao;

import com.KLF.modele.Products;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

/**
 *
 * @author Hakim
 */
public interface ProductsRepository extends JpaRepository<Products, Integer> {

    //A paged wine list function accepting a page number as a parameter returning the 100 wine names
    @Query("SELECT p FROM Products p")
    public Page<Products> winePage(Pageable pageable);

}
