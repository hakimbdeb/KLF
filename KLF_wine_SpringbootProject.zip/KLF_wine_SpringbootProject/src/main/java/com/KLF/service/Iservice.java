/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.KLF.service;

import com.KLF.modele.Products;
import java.util.List;
import org.springframework.data.domain.Page;

/**
 *
 * @author Hakim
 */
public interface Iservice {

    public String wineSearch(Integer prodID);

    public List<Products> wineFirstFifty();

    public Page<Products> wineListe(int page);

}
