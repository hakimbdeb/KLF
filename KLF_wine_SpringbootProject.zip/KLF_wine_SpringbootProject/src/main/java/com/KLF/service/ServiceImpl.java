/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.KLF.service;

import com.KLF.dao.ProductsRepository;
import com.KLF.modele.Products;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Hakim
 */
@Service
@Transactional
public class ServiceImpl implements Iservice {

    @Autowired
    private ProductsRepository productsRepository;
//1. Create a wine search function allowing you to input a wine product number, returning the name

    @Override
    public String wineSearch(Integer prodID) {
        Products pr = productsRepository.findOne(prodID);
        if (pr == null) {
            throw new RuntimeException("Produit introuvable");
        }
        return pr.getProdName();
    }

//2. Create a wine list function returning the name and price of the first 50 wines in the table
    @Override
    public List<Products> wineFirstFifty() {
        List<Products> listP = productsRepository.findAll();
        List<Products> listFifty = new ArrayList<>();
        int i = 0;
        String name;
        double prix;
        for (Products tmp : listP) {
            if (i < 50) {
                name = tmp.getProdName();
                prix = tmp.getProdSellPrice();
                Products p = new Products(name, prix);
                listFifty.add(p);

            }
        }

        return listFifty;
    }

    /*3. A paged wine list function accepting a page number as a parameter returning the 100 wine names. 
So if I pass ‘1’ as a parameter, you should return me the names of wines 1-100. 
If I pass ‘3’ as a parameter, you return wines 300-400.*/
    @Override
    public Page<Products> wineListe(int page) {
        return productsRepository.winePage(new PageRequest(page, page * 100));
    }

}
