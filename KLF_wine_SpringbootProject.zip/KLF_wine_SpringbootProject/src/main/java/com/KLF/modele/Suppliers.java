/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.KLF.modele;

import com.KLF.modele.Country;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Hakim
 */
@Entity
@Table(name = "Suppliers")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Suppliers.findAll", query = "SELECT s FROM Suppliers s")
    , @NamedQuery(name = "Suppliers.findBySuppID", query = "SELECT s FROM Suppliers s WHERE s.suppID = :suppID")
    , @NamedQuery(name = "Suppliers.findBySuppName", query = "SELECT s FROM Suppliers s WHERE s.suppName = :suppName")
    , @NamedQuery(name = "Suppliers.findBySuppAddr1", query = "SELECT s FROM Suppliers s WHERE s.suppAddr1 = :suppAddr1")
    , @NamedQuery(name = "Suppliers.findBySuppAddr2", query = "SELECT s FROM Suppliers s WHERE s.suppAddr2 = :suppAddr2")
    , @NamedQuery(name = "Suppliers.findBySuppCity", query = "SELECT s FROM Suppliers s WHERE s.suppCity = :suppCity")
    , @NamedQuery(name = "Suppliers.findBySuppPostalCode", query = "SELECT s FROM Suppliers s WHERE s.suppPostalCode = :suppPostalCode")
    , @NamedQuery(name = "Suppliers.findBySuppContact", query = "SELECT s FROM Suppliers s WHERE s.suppContact = :suppContact")
    , @NamedQuery(name = "Suppliers.findBySuppTel", query = "SELECT s FROM Suppliers s WHERE s.suppTel = :suppTel")
    , @NamedQuery(name = "Suppliers.findBySuppEmail", query = "SELECT s FROM Suppliers s WHERE s.suppEmail = :suppEmail")
    , @NamedQuery(name = "Suppliers.findBySuppURL", query = "SELECT s FROM Suppliers s WHERE s.suppURL = :suppURL")
    , @NamedQuery(name = "Suppliers.findBySuppActive", query = "SELECT s FROM Suppliers s WHERE s.suppActive = :suppActive")})
public class Suppliers implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "suppID")
    private Integer suppID;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "suppName")
    private String suppName;
    @Size(max = 60)
    @Column(name = "suppAddr1")
    private String suppAddr1;
    @Size(max = 60)
    @Column(name = "suppAddr2")
    private String suppAddr2;
    @Size(max = 45)
    @Column(name = "suppCity")
    private String suppCity;
    @Size(max = 10)
    @Column(name = "suppPostalCode")
    private String suppPostalCode;
    @Size(max = 60)
    @Column(name = "suppContact")
    private String suppContact;
    @Size(max = 12)
    @Column(name = "suppTel")
    private String suppTel;
    @Size(max = 60)
    @Column(name = "suppEmail")
    private String suppEmail;
    @Size(max = 100)
    @Column(name = "suppURL")
    private String suppURL;
    @Basic(optional = false)
    @NotNull
    @Column(name = "suppActive")
    private boolean suppActive;
    @JoinColumn(name = "suppCountryID", referencedColumnName = "CountryID")
    @ManyToOne
    private Country suppCountryID;

    public Suppliers() {
    }

    public Suppliers(Integer suppID) {
        this.suppID = suppID;
    }

    public Suppliers(Integer suppID, String suppName, boolean suppActive) {
        this.suppID = suppID;
        this.suppName = suppName;
        this.suppActive = suppActive;
    }

    public Integer getSuppID() {
        return suppID;
    }

    public void setSuppID(Integer suppID) {
        this.suppID = suppID;
    }

    public String getSuppName() {
        return suppName;
    }

    public void setSuppName(String suppName) {
        this.suppName = suppName;
    }

    public String getSuppAddr1() {
        return suppAddr1;
    }

    public void setSuppAddr1(String suppAddr1) {
        this.suppAddr1 = suppAddr1;
    }

    public String getSuppAddr2() {
        return suppAddr2;
    }

    public void setSuppAddr2(String suppAddr2) {
        this.suppAddr2 = suppAddr2;
    }

    public String getSuppCity() {
        return suppCity;
    }

    public void setSuppCity(String suppCity) {
        this.suppCity = suppCity;
    }

    public String getSuppPostalCode() {
        return suppPostalCode;
    }

    public void setSuppPostalCode(String suppPostalCode) {
        this.suppPostalCode = suppPostalCode;
    }

    public String getSuppContact() {
        return suppContact;
    }

    public void setSuppContact(String suppContact) {
        this.suppContact = suppContact;
    }

    public String getSuppTel() {
        return suppTel;
    }

    public void setSuppTel(String suppTel) {
        this.suppTel = suppTel;
    }

    public String getSuppEmail() {
        return suppEmail;
    }

    public void setSuppEmail(String suppEmail) {
        this.suppEmail = suppEmail;
    }

    public String getSuppURL() {
        return suppURL;
    }

    public void setSuppURL(String suppURL) {
        this.suppURL = suppURL;
    }

    public boolean getSuppActive() {
        return suppActive;
    }

    public void setSuppActive(boolean suppActive) {
        this.suppActive = suppActive;
    }

    public Country getSuppCountryID() {
        return suppCountryID;
    }

    public void setSuppCountryID(Country suppCountryID) {
        this.suppCountryID = suppCountryID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (suppID != null ? suppID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Suppliers)) {
            return false;
        }
        Suppliers other = (Suppliers) object;
        if ((this.suppID == null && other.suppID != null) || (this.suppID != null && !this.suppID.equals(other.suppID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.KLF.Suppliers[ suppID=" + suppID + " ]";
    }

}
