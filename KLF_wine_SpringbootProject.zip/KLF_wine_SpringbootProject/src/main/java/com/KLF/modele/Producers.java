/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.KLF.modele;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Hakim
 */
@Entity
@Table(name = "Producers")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Producers.findAll", query = "SELECT p FROM Producers p")
    , @NamedQuery(name = "Producers.findByProdID", query = "SELECT p FROM Producers p WHERE p.prodID = :prodID")
    , @NamedQuery(name = "Producers.findByProdName", query = "SELECT p FROM Producers p WHERE p.prodName = :prodName")
    , @NamedQuery(name = "Producers.findByProdPriority", query = "SELECT p FROM Producers p WHERE p.prodPriority = :prodPriority")
    , @NamedQuery(name = "Producers.findByProdURL", query = "SELECT p FROM Producers p WHERE p.prodURL = :prodURL")})
public class Producers implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "prodID")
    private Integer prodID;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 60)
    @Column(name = "prodName")
    private String prodName;
    @Column(name = "prodPriority")
    private Integer prodPriority;
    @Size(max = 100)
    @Column(name = "prodURL")
    private String prodURL;

    public Producers() {
    }

    public Producers(Integer prodID) {
        this.prodID = prodID;
    }

    public Producers(Integer prodID, String prodName) {
        this.prodID = prodID;
        this.prodName = prodName;
    }

    public Integer getProdID() {
        return prodID;
    }

    public void setProdID(Integer prodID) {
        this.prodID = prodID;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public Integer getProdPriority() {
        return prodPriority;
    }

    public void setProdPriority(Integer prodPriority) {
        this.prodPriority = prodPriority;
    }

    public String getProdURL() {
        return prodURL;
    }

    public void setProdURL(String prodURL) {
        this.prodURL = prodURL;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (prodID != null ? prodID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Producers)) {
            return false;
        }
        Producers other = (Producers) object;
        if ((this.prodID == null && other.prodID != null) || (this.prodID != null && !this.prodID.equals(other.prodID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.KLF.Producers[ prodID=" + prodID + " ]";
    }

}
