/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.KLF.modele;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Hakim
 */
@Entity
@Table(name = "colorProd")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "ColorProd.findAll", query = "SELECT c FROM ColorProd c")
    , @NamedQuery(name = "ColorProd.findByColprodID", query = "SELECT c FROM ColorProd c WHERE c.colprodID = :colprodID")
    , @NamedQuery(name = "ColorProd.findByColprodDesc", query = "SELECT c FROM ColorProd c WHERE c.colprodDesc = :colprodDesc")})
public class ColorProd implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "colprodID")
    private Integer colprodID;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "colprodDesc")
    private String colprodDesc;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "prodColorID")
    private Collection<Products> productsCollection;

    public ColorProd() {
    }

    public ColorProd(Integer colprodID) {
        this.colprodID = colprodID;
    }

    public ColorProd(Integer colprodID, String colprodDesc) {
        this.colprodID = colprodID;
        this.colprodDesc = colprodDesc;
    }

    public Integer getColprodID() {
        return colprodID;
    }

    public void setColprodID(Integer colprodID) {
        this.colprodID = colprodID;
    }

    public String getColprodDesc() {
        return colprodDesc;
    }

    public void setColprodDesc(String colprodDesc) {
        this.colprodDesc = colprodDesc;
    }

    @XmlTransient
    public Collection<Products> getProductsCollection() {
        return productsCollection;
    }

    public void setProductsCollection(Collection<Products> productsCollection) {
        this.productsCollection = productsCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (colprodID != null ? colprodID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ColorProd)) {
            return false;
        }
        ColorProd other = (ColorProd) object;
        if ((this.colprodID == null && other.colprodID != null) || (this.colprodID != null && !this.colprodID.equals(other.colprodID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.KLF.ColorProd[ colprodID=" + colprodID + " ]";
    }

}
