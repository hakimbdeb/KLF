/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.KLF.modele;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Hakim
 */
@Entity
@Table(name = "Packaging")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Packaging.findAll", query = "SELECT p FROM Packaging p")
    , @NamedQuery(name = "Packaging.findByPackID", query = "SELECT p FROM Packaging p WHERE p.packID = :packID")
    , @NamedQuery(name = "Packaging.findByPackQty", query = "SELECT p FROM Packaging p WHERE p.packQty = :packQty")})
public class Packaging implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "packID")
    private Integer packID;
    @Basic(optional = false)
    @NotNull
    @Column(name = "packQty")
    private int packQty;

    public Packaging() {
    }

    public Packaging(Integer packID) {
        this.packID = packID;
    }

    public Packaging(Integer packID, int packQty) {
        this.packID = packID;
        this.packQty = packQty;
    }

    public Integer getPackID() {
        return packID;
    }

    public void setPackID(Integer packID) {
        this.packID = packID;
    }

    public int getPackQty() {
        return packQty;
    }

    public void setPackQty(int packQty) {
        this.packQty = packQty;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (packID != null ? packID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Packaging)) {
            return false;
        }
        Packaging other = (Packaging) object;
        if ((this.packID == null && other.packID != null) || (this.packID != null && !this.packID.equals(other.packID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.KLF.Packaging[ packID=" + packID + " ]";
    }

}
