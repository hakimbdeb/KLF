/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.KLF.modele;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Hakim
 */
@Entity
@Table(name = "Products")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Products.findAll", query = "SELECT p FROM Products p")
    , @NamedQuery(name = "Products.findByProdID", query = "SELECT p FROM Products p WHERE p.prodID = :prodID")
    , @NamedQuery(name = "Products.findByProdNum", query = "SELECT p FROM Products p WHERE p.prodNum = :prodNum")
    , @NamedQuery(name = "Products.findByProdName", query = "SELECT p FROM Products p WHERE p.prodName = :prodName")
    , @NamedQuery(name = "Products.findByProdPack", query = "SELECT p FROM Products p WHERE p.prodPack = :prodPack")
    , @NamedQuery(name = "Products.findByProdRegionID", query = "SELECT p FROM Products p WHERE p.prodRegionID = :prodRegionID")
    , @NamedQuery(name = "Products.findByProdNoRequest", query = "SELECT p FROM Products p WHERE p.prodNoRequest = :prodNoRequest")
    , @NamedQuery(name = "Products.findByProdIDSupplier", query = "SELECT p FROM Products p WHERE p.prodIDSupplier = :prodIDSupplier")
    , @NamedQuery(name = "Products.findByProdDateBuy", query = "SELECT p FROM Products p WHERE p.prodDateBuy = :prodDateBuy")
    , @NamedQuery(name = "Products.findByProdQtyBuy", query = "SELECT p FROM Products p WHERE p.prodQtyBuy = :prodQtyBuy")
    , @NamedQuery(name = "Products.findByProdFormat", query = "SELECT p FROM Products p WHERE p.prodFormat = :prodFormat")
    , @NamedQuery(name = "Products.findByProdPriceBuy", query = "SELECT p FROM Products p WHERE p.prodPriceBuy = :prodPriceBuy")
    , @NamedQuery(name = "Products.findByProdLabelCharge", query = "SELECT p FROM Products p WHERE p.prodLabelCharge = :prodLabelCharge")
    , @NamedQuery(name = "Products.findByProdBottleCharge", query = "SELECT p FROM Products p WHERE p.prodBottleCharge = :prodBottleCharge")
    , @NamedQuery(name = "Products.findByProdBottleChargePerson", query = "SELECT p FROM Products p WHERE p.prodBottleChargePerson = :prodBottleChargePerson")
    , @NamedQuery(name = "Products.findByProdSellPrice", query = "SELECT p FROM Products p WHERE p.prodSellPrice = :prodSellPrice")
    , @NamedQuery(name = "Products.findByProdSoldOut", query = "SELECT p FROM Products p WHERE p.prodSoldOut = :prodSoldOut")
    , @NamedQuery(name = "Products.findByProdAvailable", query = "SELECT p FROM Products p WHERE p.prodAvailable = :prodAvailable")
    , @NamedQuery(name = "Products.findByProdComment", query = "SELECT p FROM Products p WHERE p.prodComment = :prodComment")})
public class Products implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "prodID")
    private Integer prodID;
    @Size(max = 12)
    @Column(name = "prodNum")
    private String prodNum;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 125)
    @Column(name = "prodName")
    private String prodName;
    @Basic(optional = false)
    @NotNull
    @Column(name = "prodPack")
    private int prodPack;
    @Column(name = "prodRegionID")
    private Integer prodRegionID;
    @Size(max = 12)
    @Column(name = "prodNoRequest")
    private String prodNoRequest;
    @Size(max = 12)
    @Column(name = "prodIDSupplier")
    private String prodIDSupplier;
    @Column(name = "prodDateBuy")
    @Temporal(TemporalType.DATE)
    private Date prodDateBuy;
    @Basic(optional = false)
    @NotNull
    @Column(name = "prodQtyBuy")
    private int prodQtyBuy;
    @Size(max = 10)
    @Column(name = "prodFormat")
    private String prodFormat;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "prodPriceBuy")
    private Double prodPriceBuy;
    @Column(name = "prodLabelCharge")
    private Double prodLabelCharge;
    @Column(name = "prodBottleCharge")
    private Double prodBottleCharge;
    @Column(name = "prodBottleChargePerson")
    private Double prodBottleChargePerson;
    @Column(name = "prodSellPrice")
    private Double prodSellPrice;
    @Basic(optional = false)
    @NotNull
    @Column(name = "prodSoldOut")
    private boolean prodSoldOut;
    @Basic(optional = false)
    @NotNull
    @Column(name = "prodAvailable")
    private boolean prodAvailable;
    @Size(max = 400)
    @Column(name = "prodComment")
    private String prodComment;
    @JoinColumn(name = "prodColorID", referencedColumnName = "colprodID")
    @ManyToOne(optional = false)
    private ColorProd prodColorID;

    public Products() {
    }

    public Products(Integer prodID) {
        this.prodID = prodID;
    }

    public Products(Integer prodID, String prodName, int prodPack, int prodQtyBuy, boolean prodSoldOut, boolean prodAvailable) {
        this.prodID = prodID;
        this.prodName = prodName;
        this.prodPack = prodPack;
        this.prodQtyBuy = prodQtyBuy;
        this.prodSoldOut = prodSoldOut;
        this.prodAvailable = prodAvailable;
    }

    public Products(String name, double prix) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Integer getProdID() {
        return prodID;
    }

    public void setProdID(Integer prodID) {
        this.prodID = prodID;
    }

    public String getProdNum() {
        return prodNum;
    }

    public void setProdNum(String prodNum) {
        this.prodNum = prodNum;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    public int getProdPack() {
        return prodPack;
    }

    public void setProdPack(int prodPack) {
        this.prodPack = prodPack;
    }

    public Integer getProdRegionID() {
        return prodRegionID;
    }

    public void setProdRegionID(Integer prodRegionID) {
        this.prodRegionID = prodRegionID;
    }

    public String getProdNoRequest() {
        return prodNoRequest;
    }

    public void setProdNoRequest(String prodNoRequest) {
        this.prodNoRequest = prodNoRequest;
    }

    public String getProdIDSupplier() {
        return prodIDSupplier;
    }

    public void setProdIDSupplier(String prodIDSupplier) {
        this.prodIDSupplier = prodIDSupplier;
    }

    public Date getProdDateBuy() {
        return prodDateBuy;
    }

    public void setProdDateBuy(Date prodDateBuy) {
        this.prodDateBuy = prodDateBuy;
    }

    public int getProdQtyBuy() {
        return prodQtyBuy;
    }

    public void setProdQtyBuy(int prodQtyBuy) {
        this.prodQtyBuy = prodQtyBuy;
    }

    public String getProdFormat() {
        return prodFormat;
    }

    public void setProdFormat(String prodFormat) {
        this.prodFormat = prodFormat;
    }

    public Double getProdPriceBuy() {
        return prodPriceBuy;
    }

    public void setProdPriceBuy(Double prodPriceBuy) {
        this.prodPriceBuy = prodPriceBuy;
    }

    public Double getProdLabelCharge() {
        return prodLabelCharge;
    }

    public void setProdLabelCharge(Double prodLabelCharge) {
        this.prodLabelCharge = prodLabelCharge;
    }

    public Double getProdBottleCharge() {
        return prodBottleCharge;
    }

    public void setProdBottleCharge(Double prodBottleCharge) {
        this.prodBottleCharge = prodBottleCharge;
    }

    public Double getProdBottleChargePerson() {
        return prodBottleChargePerson;
    }

    public void setProdBottleChargePerson(Double prodBottleChargePerson) {
        this.prodBottleChargePerson = prodBottleChargePerson;
    }

    public Double getProdSellPrice() {
        return prodSellPrice;
    }

    public void setProdSellPrice(Double prodSellPrice) {
        this.prodSellPrice = prodSellPrice;
    }

    public boolean getProdSoldOut() {
        return prodSoldOut;
    }

    public void setProdSoldOut(boolean prodSoldOut) {
        this.prodSoldOut = prodSoldOut;
    }

    public boolean getProdAvailable() {
        return prodAvailable;
    }

    public void setProdAvailable(boolean prodAvailable) {
        this.prodAvailable = prodAvailable;
    }

    public String getProdComment() {
        return prodComment;
    }

    public void setProdComment(String prodComment) {
        this.prodComment = prodComment;
    }

    public ColorProd getProdColorID() {
        return prodColorID;
    }

    public void setProdColorID(ColorProd prodColorID) {
        this.prodColorID = prodColorID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (prodID != null ? prodID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Products)) {
            return false;
        }
        Products other = (Products) object;
        if ((this.prodID == null && other.prodID != null) || (this.prodID != null && !this.prodID.equals(other.prodID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Products{" + "prodID=" + prodID + ", prodNum=" + prodNum + ", prodName=" + prodName + ", prodPack=" + prodPack + ", prodRegionID=" + prodRegionID + ", prodNoRequest=" + prodNoRequest + ", prodIDSupplier=" + prodIDSupplier + ", prodDateBuy=" + prodDateBuy + ", prodQtyBuy=" + prodQtyBuy + ", prodFormat=" + prodFormat + ", prodPriceBuy=" + prodPriceBuy + ", prodLabelCharge=" + prodLabelCharge + ", prodBottleCharge=" + prodBottleCharge + ", prodBottleChargePerson=" + prodBottleChargePerson + ", prodSellPrice=" + prodSellPrice + ", prodSoldOut=" + prodSoldOut + ", prodAvailable=" + prodAvailable + ", prodComment=" + prodComment + ", prodColorID=" + prodColorID + '}';
    }

}
